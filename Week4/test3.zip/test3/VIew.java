package test3;

public interface VIew {

	public <T> void say(T message);

	public <T> void add(T message);

}
