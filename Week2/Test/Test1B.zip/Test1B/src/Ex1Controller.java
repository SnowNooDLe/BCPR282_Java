
public class Ex1Controller extends Controller {
	Ex1 ex1 = new Ex1();
	
	public Ex1Controller(View theView) {
		super(theView);
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void doStuff() {
		for (int i = 0; i<=10; i++) {
			this.myView.say(i + " is " + ex1.checkNumber(i));
		}
	}
}
